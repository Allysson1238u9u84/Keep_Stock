from core.crud_base import CrudBase
from core import database
from core.database import conectar_supabase
from core.validator import Validator

class Produto(CrudBase):
    table = "produtos"
    fields = [
        "nome",
        "categoria",
        "unidade_medida",
        "descricao",
        "fornecedor",
        "valor_unitario_venda",
        "valor_unitario_custo",
        "quantidade_atual",
        "quantidade_minima",
        "controlado",
    ]

    def __init__(self, nome, categoria, unidade_medida, descricao, fornecedor, valor_unitario_venda, valor_unitario_custo, quantidade_atual, quantidade_minima, controlado, id=None, id_produto=None, **kwargs):
        self.nome = nome
        self.categoria = categoria
        self.unidade_medida = unidade_medida
        self.descricao = descricao
        self.fornecedor = fornecedor
        self.valor_unitario_venda = valor_unitario_venda
        self.valor_unitario_custo = valor_unitario_custo
        self.quantidade_atual = quantidade_atual
        self.quantidade_minima = quantidade_minima
        self.controlado = controlado
        self.id = id or id_produto
        self.id_produto = self.id
        self.db = database.conectar_supabase() # Pega o cliente do Supabase

    def validate(self):
        erros = [
            Validator.non_negative(self.nome, "nome"),
            Validator.non_negative(self.categoria, "categoria"),
            Validator.non_negative(self.unidade_medida, "unidade de medida"),
            Validator.non_negative(self.descricao, "descrição"),
            Validator.non_negative(self.fornecedor, "fornecedor"),
            Validator.non_negative(self.valor_unitario_venda, "valor_unitario_venda"),
            Validator.non_negative(self.valor_unitario_custo, "valor_unitario_custo"),
            Validator.non_negative(self.quantidade_atual, "quantidade_atual"),
            Validator.non_negative(self.quantidade_minima, "quantidade_minima"),
            Validator.non_negative(self.controlado, "controlado")
        ]
        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):
        # Classe de WHERE (Junção de dados da tabela e comparações - quantidade_produto <= quantidade_minima)
        supabase = conectar_supabase()
        try:
            supabase.table(("produtos")).select("*", count="exact").eq("id", id).execute()
            res_comparacao = supabase.table("produtos").select("*", count="exact").lte("quantidade_atual", "quantidade_minima").execute()
            return res_comparacao.count > 0
        
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
                    
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca produto e verifica se ele existe
        produto = cls.find_by_id(id)
        if not produto:
            raise ValueError("produto não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o produto porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_produto(cls, id_produto):
        supabase = conectar_supabase()
        # Busca um produto no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("produtos").select("*").eq("id", id_produto).execute()
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], id_produto=d['id_produto'], nome=d['nome'], categoria=d['categoria'], unidade_medida=d['unidade_medida'], descricao=d['descricao'], fornecedor=d['fornecedor'], valor_unitario_venda=d['valor_unitario_venda'], valor_unitario_custo=d['valor_unitario_custo'], quantidade_atual=d['quantidade_atual'], quantidade_minima=d['quantidade_minima'], controlado=d['controlado'])
        return None
    
    def inserir_produto(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o produto
        dados = {campo: getattr(self, campo) for campo in self.fields}
        if self.id:
            return self.db.table("produtos").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("produtos").insert(dados).execute()

