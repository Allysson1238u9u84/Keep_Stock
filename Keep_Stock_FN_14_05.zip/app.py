from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from core.validator import Validator
from flask_cors import CORS
from supabase import create_client, Client
from models.produto import Produto
from models.pedidos import Pedido as PedidoMovimentacao
from models.movimentacoes_estoque import Movimentacoes_estoque as Movimentacao
from models.fornecedores import Fornecedor
from models.areas_estoque import Produto as AreaEstoque
import requests
import urllib.parse


app = Flask(__name__)
CORS(app) # CORS serve para permitir a troca de informações entre o frontend e o backend

# CONFIGURAÇÕES - TOKENS E URLS
app.secret_key = '133829382937huu92uwnsjw2iqjkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk'  # Chave secreta para sessões e flash messages
INVERTEXTO_TOKEN = "25384|j9ZTOhnY61kbOHY59QagFaLy86QvrCeY"
SUPABASE_URL = "https://soikrxoppzuykrilkxii.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNvaWtyeG9wcHp1eWtyaWxreGlpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYyOTQwMjUsImV4cCI6MjA5MTg3MDAyNX0.7sUj-wWHg_Ge9xSmwfX13ec-uvunzujHlUfMnU7Wgdo" 

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY) # Login e conexão com o Supabase

def to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def get_produto_form():
    return {
        "nome": request.form.get("nome", "").strip(),
        "categoria": request.form.get("categoria", "").strip(),
        "unidade_medida": request.form.get("unidade_medida", "").strip(),
        "descricao": request.form.get("descricao", "").strip(),
        "fornecedor": request.form.get("fornecedor", "").strip(),
        "valor_unitario_venda": to_float(request.form.get("valor_unitario_venda")),
        "valor_unitario_custo": to_float(request.form.get("valor_unitario_custo")),
        "quantidade_atual": to_int(request.form.get("quantidade_atual")),
        "quantidade_minima": to_int(request.form.get("quantidade_minima")),
        "controlado": request.form.get("controlado")
    }


def get_pedido_form():
    return {
        "produto_id": to_int(request.form.get("produto_id")),
        "tipo": request.form.get("tipo", "").strip().upper(),
        "quantidade": to_int(request.form.get("quantidade")),
        "observacao": request.form.get("observacao", "").strip()
    }

@app.route("/")
def index():
    return render_template("index.html")

@app.route('/cadastrar', methods=['POST'])
def cadastrar():
    # Recebe os dados do JavaScript
    dados = request.get_json()
    
    print(f"Dados recebidos: {dados}")

    if not dados:
        return jsonify({"erro": "Dados não fornecidos"}), 400

    # Validações Básicas de Presença
    nome = dados.get('nome')
    email_cliente = dados.get('email', '').strip().lower()
    cpf_cliente = dados.get('cpf', '').strip()
    senha = dados.get('senha')

    erro_nome = Validator.required(nome, "Nome")
    if erro_nome:
        return jsonify({"erro": erro_nome}), 400

    if not Validator.validar_nome(dados):
        return jsonify({"erro": "O nome deve ter entre 1 e 120 caracteres."}), 400

    # Validação de E-mail 
    resultado_api_email = Validator.validar_email(email_cliente, INVERTEXTO_TOKEN)
    
    if not resultado_api_email:
        return jsonify({"erro": "Falha ao conectar com o validador de e-mail."}), 500
    
    
    if not resultado_api_email.get("valid_format") or not resultado_api_email.get("valid_mx"):
        return jsonify({"erro": "E-mail informado é inválido ou não existe."}), 400

    # Validação de CPF 
    
    resultado_api_cpf = Validator.validar_cpf(cpf_cliente, INVERTEXTO_TOKEN)
    
    if not resultado_api_cpf:
        return jsonify({"erro": "Falha técnica ao validar CPF. Tente novamente mais tarde."}), 500


    if not resultado_api_cpf.get("valid"):
        return jsonify({
            "erro": "CPF inválido.",
            "detalhes": "O número informado não passou na validação oficial."
        }), 400

    # Gravação no Supabase 
    try:
        novo_usuario = {
            "nome": nome,
            "email": email_cliente,
            "cpf": cpf_cliente,
            "senha": senha  
        }
        
        # Executa o insert no Supabase
        supabase.table("usuarios").insert(novo_usuario).execute()
        
        return jsonify({"mensagem": "Cadastro realizado com sucesso!"}), 201

    except Exception as e:
        print(f"Erro no Supabase: {e}")
        return jsonify({"erro": "Erro ao salvar no banco de dados. Verifique se o CPF ou E-mail já existem."}), 500

@app.route('/login', methods=['POST'])
def login():
    try:
        dados = request.get_json()
        email_login = dados.get('email').strip().lower()
        senha_login = dados.get('senha')

        resposta = supabase.table("usuarios") \
            .select("*") \
            .eq("email", email_login) \
            .execute()

        # Verifica se o usuário existe mesmo
        if not resposta.data:
            return jsonify({"erro": "E-mail não cadastrado."}), 404
        
        usuario = resposta.data[0]

        # Verifica se a senha coincide também
        if usuario.get('senha') == senha_login:
            return jsonify({
                "mensagem": "Login realizado com sucesso!",
                "nome": usuario.get('nome')
            }), 200
        else:
            return jsonify({"erro": "E-mail ou senha incorretos."}), 401

    # Se houver erro
    except Exception as e:
        print(f"Erro interno no Login: {e}")
        return jsonify({"erro": "Erro interno no servidor."}), 500

@app.route("/produtos")
def produtos():
    return render_template("produtos.html", produtos=Produto.find_all(order_by="nome"))

@app.route("/produto/salvar", methods=["POST"])
def salvar_produto():
    dados = get_produto_form()
    produto = Produto(**dados)
    erros = produto.validate()

    try:
        produto.inserir_produto()
        flash("Produto cadastrado com sucesso.", "sucesso")
        return redirect(url_for("produtos"))
    except Exception as e:
        flash(f"Erro ao cadastrar produto: {e}", "erro")
        return render_template("produtos.html", produto=dados)

@app.route("/produto/atualizar/<int:id>", methods=["POST"])
def atualizar_produto(id):
    dados = get_produto_form()
    dados["id"] = id
    produto = Produto(**dados)
    erros = produto.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("produtos.html", produto=dados)

    try:
        if not Produto.find_by_id(id):
            flash("Produto não encontrado.", "erro")
            return redirect(url_for("produtos"))

        produto.update(id)
        flash("Produto atualizado com sucesso.", "sucesso")
        return redirect(url_for("produtos"))
    except Exception as e:
        dados["id"] = id
        flash(f"Erro ao atualizar produto: {e}", "erro")
        return render_template("produtos.html", produto=dados)


@app.route("/produto/excluir/<int:id>")
def excluir_produto(id):
    try:
        Produto.safe_delete(id)
        flash("Produto excluído com sucesso.", "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao excluir produto: {e}", "erro")
    return redirect(url_for("produtos"))

@app.route("/pedidos")
def pedidos():
    return render_template("pedidos.html", pedidos=PedidoMovimentacao.find_all_with_product())


@app.route("/pedido/novo/<tipo>/<int:produto_id>")
def novo_pedido(tipo, produto_id):
    produto = Produto.find_by_id(produto_id)
    tipo = tipo.upper()

    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("produtos"))

    if tipo not in ["ENTRADA", "SAIDA"]:
        flash("Tipo de pedido inválido.", "erro")
        return redirect(url_for("produtos"))

    return render_template("formulario_pedido.html", produto=produto, tipo=tipo, pedido=None)


@app.route("/pedido/salvar", methods=["POST"])
def salvar_pedido():
    dados = get_pedido_form()
    produto = Produto.find_by_id(dados["produto_id"])
    pedido = PedidoMovimentacao(**dados)
    erros = pedido.validate()

    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("produtos"))

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("formulario_pedido.html", produto=produto, tipo=dados["tipo"], pedido=dados)

    try:
        pedido.insert()
        flash("Pedido criado com sucesso.", "sucesso")
        return redirect(url_for("pedidos"))
    except Exception as e:
        flash(f"Erro ao criar pedido: {e}", "erro")
        return render_template("formulario_pedido.html", produto=produto, tipo=dados["tipo"], pedido=dados)


@app.route("/pedido/processar/<int:id>")
def processar_pedido(id):
    try:
        mensagem = PedidoMovimentacao.processar(id)
        flash(mensagem, "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao processar pedido: {e}", "erro")
    return redirect(url_for("pedidos"))


@app.route("/pedido/cancelar/<int:id>")
def cancelar_pedido(id):
    try:
        mensagem = PedidoMovimentacao.cancelar(id)
        flash(mensagem, "sucesso")
    except ValueError as e:
        flash(str(e), "erro")
    except Exception as e:
        flash(f"Erro ao cancelar pedido: {e}", "erro")
    return redirect(url_for("pedidos"))


@app.route("/movimentacoes")
def movimentacoes():
    return render_template("movimentacoes.html", movimentacoes=Movimentacao.find_all_with_product())


@app.route("/areas_controladas")
def areas_controladas():
    """Exibe todas as áreas controladas"""
    areas = AreaEstoque.find_all(order_by="nome")
    return render_template("areas_controladas.html", areas=areas)


@app.route("/area_controlada/nova")
def nova_area_controlada():
    """Formulário para adicionar nova área controlada"""
    return render_template("formulario_area_controlada.html", area=None)


@app.route("/area_controlada/adicionar", methods=["POST"])
def adicionar_area_controlada():
    """Adiciona nova área controlada"""
    try:
        dados = {
            "nome": request.form.get("nome", "").strip(),
            "temperatura_minima": to_float(request.form.get("temp_minima")),
            "temperatura_maxima": to_float(request.form.get("temp_maxima")),
            "area_vinculada": request.form.get("area_vinculada", "").strip(),
            "lote_controlado": request.form.get("lote_controlado", "").strip(),
            "produto_controlado": request.form.get("produto_controlado", "").strip(),
            "quantidade_maxima": to_int(request.form.get("quantidade_maxima"))
        }
        
        area = AreaEstoque(**dados)
        area.insert()
        flash("Área controlada cadastrada com sucesso.", "sucesso")
        return redirect(url_for("areas_controladas"))
    except Exception as e:
        flash(f"Erro ao cadastrar área controlada: {e}", "erro")
        return redirect(url_for("areas_controladas"))


@app.route("/fornecedores")
def fornecedores():
    """Exibe todos os fornecedores"""
    fornecedores_list = Fornecedor.find_all(order_by="nome")
    return render_template("fornecedores.html", fornecedores=fornecedores_list)


@app.route("/fornecedor/novo")
def novo_fornecedor():
    """Formulário para adicionar novo fornecedor"""
    return render_template("formulario_fornecedor.html", fornecedor=None)


@app.route("/fornecedor/adicionar", methods=["POST"])
def adicionar_fornecedor():
    """Adiciona novo fornecedor"""
    try:
        dados = {
            "nome": request.form.get("nome", "").strip(),
            "cnpj": request.form.get("cnpj", "").strip(),
            "telefone": request.form.get("telefone", "").strip(),
            "email": request.form.get("email", "").strip().lower(),
            "cep": request.form.get("cep", "").strip(),
            "produto": request.form.get("produto", "").strip()
        }
        
        fornecedor = Fornecedor(**dados)
        fornecedor.insert()
        flash("Fornecedor cadastrado com sucesso.", "sucesso")
        return redirect(url_for("fornecedores"))
    except Exception as e:
        flash(f"Erro ao cadastrar fornecedor: {e}", "erro")
        return redirect(url_for("fornecedores"))

if __name__ == "__main__":
    app.run(debug=True)
