from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Cliente(CrudBase):
    table = "cliente"
    fields = [
        "nome",
        "cpf",
        "cnpj"
        "telefone",
        "email",
        "endereco"
    ]
 
    def __init__(self, nome, cpf_cnpj, telefone, email, endereco):
        self.nome = nome
        self.cpf = cpf
        self.cnpj = cnpj
        self.telefone = telefone
        self.email = email
        self.endereco = endereco
 
    def validate(self):
        erros = [
            Validator.validar_nome(self.nome, "nome"),
            Validator.required(self.endereco, "endereco"),
            Validator.validar_email(self.email, "email"),
            Validator.non_negative(self.telefone, "telefone"),
            Validator.non_negative(self.cpf, "cpf"),
            Validator.non_negative(self.cnpj, "cpnpj"),
        ]

    @classmethod
    def has_related_records(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                "SELECT COUNT(*) FROM pedidos WHERE cliente_id = %s",
                "SELECT COUNT(*) FROM saidas_produtos WHERE cliente_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()
 
    @classmethod
    def safe_delete(cls, id):
        cliente = cls.find_by_id(id)
        if not cliente:
            raise ValueError("Cliente não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o cliente porque ele possui pedidos ou movimentações vinculadas.")
        cls.delete(id)
 