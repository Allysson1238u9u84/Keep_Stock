from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Devolucao(CrudBase):
    table = "devolucao"
    fields = [
        "id_lote",
        "motivo"
    ]
 
    def __init__(self, id_lote, motivo):
        self.id_lote = id_lote
        self.motivo = motivo
 
    def validate(self):
        erros = [
            Validator.required(self.id_lote, "id do lote"),
            Validator.required(self.motivo, "motivo")
        ]
        return [erro for erro in erros if erro]
 
    @classmethod
    def has_related_records(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()
 
    @classmethod
    def safe_delete(cls, id):
        devolucao = cls.find_by_id(id)
        if not devolucao :
            raise ValueError("Devolução não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o devolução porque ele possui tabelas vinculadas.")
        cls.delete(id)
 