from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Usuarios(CrudBase):
    table = "usuarios"
    fields = [
        "nome",
        "email",
        "senha",
        "cpf",
        "telefone",
        "ativo",
        "criado_em"
    ]
 
    def __init__(self, nome, email, senha, cpf,
                 telefone, ativo, criado_em):
        self.nome = nome
        self.email = email
        self.senha = senha
        self.cpf = cpf
        self.telefone = telefone
        self.ativo = ativo
        self.criado_em = criado_em
        self.db = Database.get_client() # Pega o cliente do Supabase
 
    def validate(self):
        erros = [
            Validator.validar_nome(self.nome, "nome"),
            Validator.validar_email(self.email, "email"),
            Validator.non_negative(self.senha, "senha"),
            Validator.validar_cpf(self.cpf, "cpf"),
            Validator.non_negative(self.telefone, "telefone"),
            Validator.required(self.ativo, "ativo"),
            Validator.required(self.criado_em, "criado_em")
        ]
        return [erro for erro in erros if erro]
    
    @classmethod
    def has_related_records(cls, id):
        supabase = conectar_supabase()
        try:
            supabase.table(("usuarios")).select("*", count="exact").eq("id", id).execute()
            res_mov = supabase.table("movimentacao") \
                .select("*", count="exact") \
                .eq("id_usuario", id) \
                .limit(1) \
                .execute()
            res_not = supabase.table("notificacoes") \
                .select("*", count="exact") \   
                .eq("id_usuario", id) \
                .limit(1) \
                .execute()
            res_mov_estoque = supabase.table("movimentacoes_estoque") \
                .select("*", count="exact") \   
                .eq("id_usuario", id) \
                .limit(1) \
                .execute()
            res_inspecoes = supabase.table("inspecoes_estoque") \   
                .select("*", count="exact") \   
                .eq("id_usuario", id) \
                .limit(1) \
                .execute()
            res_entradas = supabase.table("entradas_produtos") \   
                .select("*", count="exact") \
                .eq("id_usuario", id) \
                .limit(1) \
                .execute()
            res_funcionarios = supabase.table("funcionarios") \
                .select("*", count="exact") \
                .eq("id_usuario", id) \
                .limit(1) \
                .execute()
                
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
                
                
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca usuario e verifica se ele existe
        usuario = cls.find_by_id(id)
        if not usuario:
            raise ValueError("usuario não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o usuario porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_usuario(cls, id_usuario):
        supabase = conectar_supabase()
        # Busca um usuario no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("usuarios").select("*").eq("id", id_usuario).execute()
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], nome=d['nome'], email=d['email'], senha=d['senha'], cpf=d['cpf'], telefone=d['telefone'], ativo=d['ativo'], criado_em=d['criado_em'])
        return None
    
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o usuário
        dados = {"nome": self.nome, "email": self.email, "senha": self.senha, "cpf": self.cpf, "telefone": self.telefone, "ativo": self.ativo, "criado_em": self.criado_em}
        if self.id:
            return self.db.table("usuarios").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("usuarios").insert(dados).execute()

