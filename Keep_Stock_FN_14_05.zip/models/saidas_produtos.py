from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Saidas_produtos(CrudBase):
    table = "saidas_produtos"
    fields = [
        "id_lote",
        "id_usuario",
        "id_cliente",
        "quantidade",
        "data_saida"
    ]
 
    def __init__(self, id_lote, id_usuario, id_cliente, quantidade, data_saida=None):
        self.id_lote = id_lote
        self.id_usuario = id_usuario
        self.id_cliente = id_cliente
        self.quantidade = quantidade
        self.data_saida = data_saida
 
    def validate(self):
        erros = [
            Validator.required(self.id_lote, "lote"),
            Validator.required(self.id_usuario, "usuário"),
            Validator.required(self.id_cliente, "cliente"),
            Validator.non_negative(self.quantidade, "quantidade")
        ]
        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):
        try:
            # Consulta na tabela Lotes + Clientes
            supabase = conectar_supabase()
            supabase.table(("saidas_produtos")).select("*", count="exact").eq("id", id).execute()
            res_lote = supabase.table("lotes") \
                .select("*", count="exact") \
                .eq("id", id) \
                .limit(1) \
                .execute()
            res_usuario = supabase.table("usuarios") \
                .select("*", count="exact") \
                .eq("id", id) \
                .limit(1) \
                .execute()
            res_clientes = supabase.table("clientes") \
                .select("*", count="exact") \
                .eq("id", id) \
                .limit(1) \ 
                .execute()

            total = (res_mov.count or 0) + (res_clientes.count or 0) # O count exato fica em res.count
        
            return total > 0
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False