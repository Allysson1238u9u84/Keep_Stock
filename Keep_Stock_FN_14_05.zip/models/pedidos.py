from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Pedido(CrudBase):
    table = "pedido"
    fields = [
        "id_cliente",
        "data_pedido",
        "status_pedido",
        "data_prevista"
    ]
 
    def __init__(self, id_cliente, data_pedido, status_pedido, data_prevista):
        self.id_cliente = id_cliente
        self.data_pedido = data_pedido
        self.status_pedido = status_pedido
        self.data_prevista = data_prevista
 
    def validate(self):
        erros = [
            Validator.required(self.data_pedido, "data_pedido"),
            Validator.required(self.status_pedido, "status_pedido"),
            Validator.required(self.data_prevista, "data_prevista"),
        ]
        return [erro for erro in erros if erro]
 
    @classmethod
    def has_related_records(cls, id):
        supabase = conectar_supabase()
        try:
            supabase.table(("pedidos")).select("*", count="exact").eq("id", id).execute()
            res_pedido_itens = supabase.table("pedido_itens") \
            .select("*", count="exact") \
            .eq("id_pedido", id) \
            .limit(1) \
            .execute()
            res_pedido_movimentacao = supabase.table("pedido_movimentacao") \
            .select("*", count="exact") \
            .eq("id_pedido", id) \
            .limit(1) \
            .execute()
            
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
                
                
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca o pedido e verifica se ele existe
        pedido = cls.find_by_id(id)
        if not pedido:
            raise ValueError("pedido não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o pedido porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_pedido(cls, id_pedido):
        supabase = conectar_supabase()
        # Busca um pedido no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("pedidos").select("*").eq("id", id_pedido).execute()
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], id_cliente=d['id_cliente'], data_pedido=d['data_pedido'], status_pedido=d['status_pedido'], data_prevista=d['data_prevista'])
        return None
    
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o pedido
        dados = {"id_cliente": self.id_cliente, "data_pedido": self.data_pedido, "status_pedido": self.status_pedido, "data_prevista": self.data_prevista}
        if self.id:
            return self.db.table("pedidos").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("pedidos").insert(dados).execute()

 
 