from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Cliente(CrudBase):
    table = "cliente"
    fields = [
        "nome",
        "cpf",
        "cnpj"
        "telefone",
        "email",
        "endereco"
    ]
 
    def __init__(self, nome, cpf_cnpj, telefone, email, endereco):
        self.nome = nome
        self.cpf = cpf
        self.cnpj = cnpj
        self.telefone = telefone
        self.email = email
        self.endereco = endereco
        self.db = Database.get_client() # Pega o cliente do Supabase
 
    def validate(self):
        erros = [
            Validator.validar_nome(self.nome, "nome"),
            Validator.required(self.endereco, "endereco"),
            Validator.validar_email(self.email, "email"),
            Validator.non_negative(self.telefone, "telefone"),
            Validator.non_negative(self.cpf, "cpf"),
            Validator.non_negative(self.cnpj, "cpnpj"),
        ]

    @classmethod
    def safe_delete(cls, id):
        cliente = cls.find_by_id(id)
        if not cliente:
            raise ValueError("Cliente não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o cliente porque ele possui pedidos ou movimentações vinculadas.")
        cls.delete(id)
        
    @classmethod
    def has_related_records(cls, id):
        supabase = conectar_supabase()
         # Busca as conexões com outras tabelas relacionadas ao a esta (devoluções)
        try:
            supabase.table(("cliente")).select("*", count="exact").eq("id", id).execute()
            res_pedidos = supabase.table("pedidos") \
            .select("*", count="exact") \
            .eq("id_cliente", id) \
            .limit("1") \
            .execute()
            res_saidas_produtos = supabase.table("saidas_produtos") \
            .select("*", count="exact") \
            .eq("id_cliente", id) \
            .limit(1) \
            .execute()
            
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
                    
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca o cliente e verifica se ele existe
        lote = cls.find_by_id(id)
        if not lote:
            raise ValueError("Cliente não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o cliente porque ele possui pedidos ou movimentações vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_cliente(cls, id_cliente):
        supabase = conectar_supabase()
        # Busca um cliente no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("clientes").select("*").eq("id", id_cliente).execute()
        if res.data:
            d = res.data[0]
            return cls(id_cliente=d['id_cliente'], )
        return None
    
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o cliente
        dados = {"nome": self.nome, "cpf": self.cpf, "cnpj": self.cnpj, "telefone": self.telefone, "email": self.email, "endereco": self.endereco}
        if self.id:
            return self.db.table("clientes").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("clientes").insert(dados).execute()



 
 