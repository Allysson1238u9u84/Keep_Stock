from datetime import datetime
from core.crud_base import CrudBase
from core.database import conectar_supabase


class Movimentacoes_estoque(CrudBase):
    table = "movimentacoes_estoque"
    fields = [
        "id_lote",
        "id_usuario",
        "tipo_movimentacao", 
        "quantidade", 
        "data_hora"]

    def __init__(self, id_lote, id_usuario,tipo_movimentacao, quantidade, data_hora=None):
        self.id_lote = id_lote
        self.id_usuario = id_usuario
        self.tipo_movimentacao = tipo_movimentacao
        self.quantidade = quantidade
        self.data_hora = data_hora or datetime.now()
        self.db = Database.get_client() # Pega o cliente do Supabase

    @classmethod
    def has_related_records(cls, id):
        try:
            # Consulta na tabela Movimentação + Fornecedor
            res_mov = supabase.table("movimentacao") \
                .select("*", count="exact") \
                .eq("id_fornecedor", id) \
                .limit(1) \
                .execute()
        
            # Consulta na tabela lotes
            res_lotes = supabase.table("lotes") \
                .select("*", count="exact") \
                .eq("id_fornecedor", id) \
                .limit(1) \
                .execute()

            total = (res_mov.count or 0) + (res_lotes.count or 0) # O count exato fica em res.count
        
            return total > 0
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False