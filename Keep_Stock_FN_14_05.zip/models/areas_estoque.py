from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator

class Produto(CrudBase):
    table = "areas_estoque"
    fields = [
        "rua_prat",
        "area_prat",
        "nivel_prat",
        "distancia_entre_prat",
        "descricao",
        "temperatura_max",
        "temperatura_min",
        "id_lote",
        "id_area",
    ]

    def __init__(self, nome, gavetas, refrigeradores_disponiveis, temperatura_atual,temperatura_min, temperatura_max, id_lote, id_camara_fria):
        self.nome = nome
        self.gavetas = gavetas
        self.refrigeradores_disponiveis = refrigeradores_disponiveis
        self.temperatura_atual = temperatura_atual
        self.temperatura_min = temperatura_min
        self.temperatura_max = temperatura_max
        self.id_lote = id_lote
        self.id_camara_fria = id_camara_fria
        self.db = Database.get_client() # Pega o cliente do Supabase

    def validate(self):
        erros = [
            Validator.required(self.nome, "nome"),
            Validator.non_negative(self.gavetas, "gavetas"),
            Validator.non_negative(self.refrigeradores_disponiveis, "refrigeradores_disponiveis"),
            Validator.non_negative(self.temperatura_atual, "temperatura_atual"),
            Validator.non_negative(self.temperatura_min, "temperatura_min"),
            Validator.non_negative(self.temperatura_max, "temperatura_max"),
        ]
        return [erro for erro in erros if erro]  

    @classmethod
    def max_stock(cls, id):
        # Classe de WHERE (Junção de dados da tabela e comparações - temperatura_atual <= temperatura_minima)
        supabase = conectar_supabase()
        try:
            supabase.table(("lotes")).select("*", count="exact").eq("id", id).execute()
            res_comparacao = supabase.table("lotes").select("*", count="exact").lte("temperatura_atual", "temperatura_minima").execute()
            return res_comparacao.count > 0
        
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
            
    @classmethod
    def safe_delete(cls, id):
        area = cls.find_by_id(id)
        if not area:
            raise ValueError("Área de estoque não encontrada.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir a área de estoque porque ela possui tabelas vinculadas.")
        cls.delete(id)
        
    @classmethod
    def has_related_records(cls, id):
        supabase = conectar_supabase()
         # Busca as conexões com outras tabelas relacionadas ao a esta (Áreas de estoque)
        try:
            supabase.table(("areas_estoque")).select("*", count="exact").eq("id", id).execute()
            res_lotes = supabase.table("lotes") \
            .select("*", count="exact") \
            .eq("id_area", id) \
            .limit(1) \
            .execute()
            
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
                    
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca a Área de Estoque e verifica se ela existe
        area = cls.find_by_id(id)
        if not area:
            raise ValueError("Área de estoque não encontrada.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir a área de estoque porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_cliente(cls, id_cliente):
        supabase = conectar_supabase()
        # Busca uma Área de Estoque no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("areas_estoque").select("*").eq("id_cliente", id_cliente).execute()
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], nome=d['nome'], gavetas=d['gavetas'], refrigeradores_disponiveis=d['refrigeradores_disponiveis'], temperatura_atual=d['temperatura_atual'], temperatura_min=d['temperatura_min'], temperatura_max=d['temperatura_max'], id_lote=d['id_lote'], id_camara_fria=d['id_camara_fria'])
        return None
    
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza área de estoque
        dados = {"nome": self.nome, "gavetas": self.gavetas, "refrigeradores_disponiveis": self.refrigeradores_disponiveis, "temperatura_atual": self.temperatura_atual, "temperatura_min": self.temperatura_min, "temperatura_max": self.temperatura_max, "id_lote": self.id_lote, "id_camara_fria": self.id_camara_fria}
        if self.id:
            return self.db.table("areas_estoque").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("areas_estoque").insert(dados).execute()


