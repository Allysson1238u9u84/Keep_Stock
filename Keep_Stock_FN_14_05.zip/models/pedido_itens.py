from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class pedido_itens(CrudBase):
    table = "pedido_itens"
    fields = [
        "id_pedido",
        "id_lote",
        "id_produto",
        "quantidade",
        "preco_unitario"
    ]
 
    def __init__(self, id_pedido, id_lote, id_produto, quantidade,
                 preco_unitario):
        self.id_pedido = id_pedido
        self.id_lote = id_lote
        self.id_produto = id_produto
        self.quantidade = quantidade
        self.preco_unitario = preco_unitario
 
    def validate(self):
        erros = [
            Validator.required(self.id_pedido, "id_pedido"),
            Validator.required(self.id_lote, "id_lote"),
            Validator.required(self.id_produto, "id_produto"),
            Validator.non_negative(self.quantidade, "quantidade"),
            Validator.non_negative(self.preco_unitario, "preco_unitario")
        ]
        return [erro for erro in erros if erro]
    
    @classmethod
    def has_related_records(cls, id):
        supabase = conectar_supabase()
        try:
            supabase.table(("pedido_itens")).select("*", count="exact").eq("id", id).execute()
            res_pedidos = supabase.table("pedidos") \
            .select("*", count="exact") \
            .eq("id", id) \
            .limit(1) \
            .execute()
            res_pedido_lote = supabase.table("lotes") \
            .select("*", count="exact") \
            .eq("id_pedido_itens", id) \
            .limit(1) \
            .execute()
            res_pedido_produtos = supabase.table("produtos") \
            .select("*", count="exact") \
            .eq("id_pedido_itens", id) \
            .limit(1) \
            .execute()
            
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
                
                
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca os itens do pedido e verifica se ele existe
        pedido = cls.find_by_id(id)
        if not pedido:
            raise ValueError("pedido de itens não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o pedido porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_itens_pedido(cls, id_pedido_itens):
        supabase = conectar_supabase()
        # Busca os itens de um pedido no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("pedido_itens").select("*").eq("id", id_pedido_itens).execute()
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], id_pedido=d['id_pedido'], id_lote=d['id_lote'], id_produto=d['id_produto'], quantidade=d['quantidade'], preco_unitario=d['preco_unitario'])
        return None
    
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o itens de um pedido
        dados = {"id_pedido": self.id_pedido, "id_lote": self.id_lote, "id_produto": self.id_produto, "quantidade": self.quantidade, "preco_unitario": self.preco_unitario}
        if self.id:
            return self.db.table("pedido_itens").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("pedido_itens").insert(dados).execute()
 
 
 