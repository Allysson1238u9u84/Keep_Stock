from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Fornecedor(CrudBase):
    table = "fornecedores"
    fields = [
        "nome",
        "cnpj",
        "telefone",
        "email",
        "endereço",
        "prod_fornecedor"
    ]
 
    def __init__(self, nome, cnpj, telefone, email,
                 endereço, prod_fornecedor):
        self.nome = nome
        self.cnpj = cnpj
        self.telefone = telefone
        self.email = email
        self.endereço = endereço
        self.prod_fornecedor = prod_fornecedor
        self.db = Database.get_client() # Pega o cliente do Supabase
 
    def validate(self):
        erros = [
            Validator.validar_nome(self.nome, "nome"),
            Validator.validar_cnpj(self.cnpj, "cnpj"),
            Validator.non_negative(self.telefone, "telefone"),
            Validator.validar_email(self.email, "email"),
            Validator.required(self.endereco, "endereco"),
            Validator.required(self.prod_fornecedor, "prod_fornecedor")
        ]
        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):
        supabase = conectar_supabase()
        try:
            # Consulta na tabela movimentacao
            res_mov = supabase.table("movimentacao") \
                .select("*", count="exact") \
                .eq("id_fornecedor", id) \
                .limit(1) \
                .execute()
        
            # Consulta na tabela lotes
            res_lotes = supabase.table("lotes") \
                .select("*", count="exact") \
                .eq("id_fornecedor", id) \
                .limit(1) \
                .execute()

            total = (res_mov.count or 0) + (res_lotes.count or 0) # O count exato fica em res.count
        
            return total > 0
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
 
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca fornecedor e verifica se ele existe
        fornecedor = cls.find_by_id(id)
        if not fornecedor:
            raise ValueError("fornecedor não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o fornecedor porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_fornecedor(cls, id_fornecedor):
        supabase = conectar_supabase()
        # Busca um fornecedor no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("fornecedor").select("*").eq("id_fornecedor", id_fornecedor).execute()
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], nome=d['nome'], cnpj=d['cnpj'], telefone=d['telefone'], email=d['email'], endereço=d['endereço'], prod_fornecedor=d['prod_fornecedor'])
        return None
    
    def salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o fornecedor
        dados = {"nome": self.nome, "cnpj": self.cnpj, "telefone": self.telefone, "email": self.email, "endereço": self.endereço, "prod_fornecedor": self.prod_fornecedor}
        if self.id:
            return self.db.table("fornecedor").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("fornecedor").insert(dados).execute()

 