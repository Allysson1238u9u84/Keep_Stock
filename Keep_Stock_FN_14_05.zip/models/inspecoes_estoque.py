from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Inspecoes_produto(CrudBase):
    table = "inspecoes_produto"
    fields = [
        "id_lote",
        "quantidade_contada",
        "status_inspecoes_estoque",
        "observacao",
        "id_usuario",
        "data_inspecao"
    ]
 
    def __init__(self, id_lote, quantidade_contada, status_inspecoes_estoque, observacao, id_usuario, data_inspecao):
        self.id_lote = id_lote
        self.quantidade_contada = quantidade_contada
        self.status_inspecoes_estoque = status_inspecoes_estoque
        self.observacao = observacao
        self.id_usuario = id_usuario
        self.data_inspecao = data_inspecao
 
    def validate(self):
        erros = [
            Validator.required(self.observacao, "observacao"),
            Validator.required(self.status_inspecoes_estoque, "status da inspecoes de estoque"),
            Validator.required(self.id_lote, "id do lote"),
            Validator.required(self.id_usuario, "id do usuario"),
            Validator.required(self.quantidade_contada, "quantidade contada")
        ]
        return [erro for erro in erros if erro]
 
    @classmethod
    def has_related_records(cls, id):
        supabase = conectar_supabase()
        try:
            supabase.table(("inspecoes_produto")).select("*", count="exact").eq("id", id).execute()
            res_lote = supabase.table("lotes") \
                .select("*", count="exact") \
                .eq("id", self.id_lote) \
                .limit(1) \
                .execute()
            res_usuario = supabase.table("usuarios")
                .select("*", count="exact")
                .eq("id", self.id_usuario)
                .limit(1)
                .execute()
                
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
                     
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca os itens do pedido e verifica se ele existe
        pedido = cls.find_by_id(id)
        if not pedido:
            raise ValueError("pedido de itens não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o pedido porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_inpecoes_estoque(cls, id_inspecao_estoque):
        supabase = conectar_supabase()
        # Busca as inspeções de estoque no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("inspecoes_produto").select("*").eq("id", id_inspecao_estoque).execute()
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], id_lote=d['id_lote'], quantidade_contada=d['quantidade_contada'], status_inspecoes_estoque=d['status_inspecoes_estoque'], observacao=d['observacao'], id_usuario=d['id_usuario'], data_inspecao=d['data_inspecao'])
        return None
    
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza as inspeções de estoque
        dados = {"id_lote": self.id_lote, "quantidade_contada": self.quantidade_contada, "status_inspecoes_estoque": self.status_inspecoes_estoque, "observacao": self.observacao, "id_usuario": self.id_usuario, "data_inspecao": self.data_inspecao}
        if self.id:
            return self.db.table("inspecoes_produto").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("inspecoes_produto").insert(dados).execute()
 
 
 