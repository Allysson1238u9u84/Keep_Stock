from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Descartes(CrudBase):
    table = "descartes"
    fields = [
        "id_lote",
        "id_produto",
        "motivo",
        "quantidade",
        "data_descarte",
        "observacao"
    ]
 
    def __init__(self, id_lote, id_produto, motivo, quantidade, data_descarte, observacao):
        self.id_lote = id_lote
        self.id_produto = id_produto
        self.motivo = id_motivo
        self.quantidade = quantidade
        self.data_descarte = data_descarte
        self.observacao = observacao
 
    def validate(self):
        erros = [
            Validator.required(self.id_lote, "id_lote"),
            Validator.required(self.id_produto, "id_produto"),
            Validator.required(self.motivo, "motivo"),
            Validator.non_negative(self.quantidade, "quantidade"),
            Validator.required(self.data_descarte, "data_descarte"),
            Validator.required(self.observacao, "observacao")
        ]
        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):
        try:
            supabase = conectar_supabase()
            supabase.table(("entradas_produtos")).select("*", count="exact").eq("id", id).execute()
            res_lote = supabase.table("lotes") \
                .select("*", count="exact") \
                .eq("id", id) \
                .limit(1) \
                .execute()
            res_usuario = supabase.table("produto") \
                .select("*", count="exact") \
                .eq("id", id) \
                .limit(1) \
                .execute()

            total = (res_mov.count or 0) + (res_fornecedores.count or 0) # O count exato fica em res.count
        
            return total > 0
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
    
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca descarte e verifica se ele existe
        descarte = cls.find_by_id(id)
        if not descarte:
            raise ValueError("descarte não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o descarte porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_usuario(cls, id_usuario):
        supabase = conectar_supabase()
        # Busca o descarte e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("descartes").select("*").eq("id", id_usuario).execute()
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], id_lote=d['id_lote'], id_produto=d['id_produto'], motivo=d['motivo'], quantidade=d['quantidade'], data_descarte=d['data_descarte'], observacao=d['observacao'])
        return None
    
    @classmethod
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o descarte
        dados = {"id_lote": self.id_lote, "id_produto": self.id_produto, "motivo": self.motivo, "quantidade": self.quantidade, "data_descarte": self.data_descarte, "observacao": self.observacao}
        if self.id:
            return self.db.table("descartes").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("descartes").insert(dados).execute()

 
 