from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator

class Produto(CrudBase):
    table = "camaras_frias"
    fields = [
        "nome",
        "gavetas",
        "refrigeradores_disponiveis"
        "temperatura_atual",
        "temperatura_min",
        "temperatura_max",
        "id_camara_fria",
    ]

    def __init__(self, nome, gavetas, refrigeradores_disponiveis, temperatura_atual,temperatura_min, temperatura_max, id_camara_fria):
        self.nome = nome
        self.gavetas = gavetas
        self.refrigeradores_disponiveis = refrigeradores_disponiveis
        self.temperatura_atual = temperatura_atual
        self.temperatura_min = temperatura_min
        self.temperatura_max = temperatura_max
        self.id_camara_fria = id_camara_fria
        self.db = Database.get_client() # Pega o cliente do Supabase

    def validate(self):
        erros = [
            Validator.required(self.nome, "nome"),
            Validator.non_negative(self.gavetas, "gavetas"),
            Validator.non_negative(self.refrigeradores_disponiveis, "refrigerdores_disponiveis"),
            Validator.non_negative(self.temperatura_atual, "temperatura_atual"),
            Validator.non_negative(self.temperatura_min, "temperatura_min"),
            Validator.non_negative(self.temperatura_max, "temperatura_max"),
        ]
        return [erro for erro in erros if erro]  
                    
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca a câmara fria e verifica se ela existe
        lote = cls.find_by_id(id)
        if not lote:
            raise ValueError("Câmara fria não encontrada.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir a câmara fria porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_cliente(cls, id_cliente):
        supabase = conectar_supabase()
        # Busca uma câmra fria no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("camaras_frias").select("*").eq("id", id_camara).execute()
        if res.data:
            d = res.data[0]
            return cls(id_camara=d['id_camara'], )
        return None
    
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza câmara fria
        dados = {"nome": self.nome, "gavetas": self.gavetas, "refrigeradores_disponiveis": self.refrigeradores_disponiveis, "temperatura_atual": self.temperatura_atual, "temperatura_min": self.temperatura_min, "temperatura_max": self.temperatura_max, "id_camara_fria": self.id_camara_fria}
        if self.id:
            return self.db.table("camaras_frias").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("camaras_frias").insert(dados).execute()


