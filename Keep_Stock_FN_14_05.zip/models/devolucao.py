from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Devolucao(CrudBase):
    table = "devolucao"
    fields = [
        "id_lote",
        "motivo"
    ]
 
    def __init__(self, id_lote, motivo):
        self.id_lote = id_lote
        self.motivo = motivo
        self.db = Database.get_client() # Pega o cliente do Supabase
 
    def validate(self):
        erros = [
            Validator.required(self.id_lote, "id do lote"),
            Validator.required(self.motivo, "motivo")
        ]
        return [erro for erro in erros if erro]

    @classmethod
    def has_related_records(cls, id):
        supabase = conectar_supabase()
         # Busca as conexões com outras tabelas relacionadas ao a esta (devoluções)
        try:
            supabase.table(("devolucao")).select("*", count="exact").eq("id", id).execute()
            res_lote = supabase.table("lotes") \
            .select("*", count="exact") \
            .eq("id_devolucao", id) \
            .limit(1) \
            .execute()
          
            return total > 0
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
                    
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca a devolução e verifica se ele existe
        lote = cls.find_by_id(id)
        if not lote:
            raise ValueError("Devolução não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir a devolução porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_devolucao(cls, id_devolucao):
        supabase = conectar_supabase()
        # Busca uma devolução no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("devolucao").select("*").eq("id", id_devolucao).execute()
        if res.data:
            d = res.data[0]
            return cls(id_devolucao=d['id_devolucao'], )
        return None
    
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza a devolução
        dados = {"id_lote": self.id_lote, "motivo": self.motivo}
        if self.id:
            return self.db.table("devolucao").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("devolucao").insert(dados).execute()


 