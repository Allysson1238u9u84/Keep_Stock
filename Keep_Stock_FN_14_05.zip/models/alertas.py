from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Alertas(CrudBase):
    table = "alertas"
    fields = [
        "id_camara",
        "id_produto",
        "tipo_alerta",
        "mensagem",
        "nivel",
        "data_criacao"
    ]
 
    def __init__(self, id_camara, id_produto, tipo_alerta, mensagem, nivel, data_criacao):
        self.id_camara = id_camara
        self.id_produto = id_produto
        self.tipo_alerta = tipo_alerta
        self.mensagem = mensagem
        self.nivel = nivel
        self.data_criacao = data_criacao
 
 
    def validate(self):
        erros = [
            Validator.required(self.mensagem, "mensagem"),
            Validator.required(self.id_camara, "id_camara"),
            Validator.non_negative(self.data_criacao, "data_criacao"),
            Validator.required(self.id_produto, "id_produto"),
            Validator.required(self.tipo_alerta, "tipo_alerta"),
            Validator.required(self.nivel, "nivel"),
           
 
        ]
        return [erro for erro in erros if erro]
    
    @classmethod
    def has_related_records(cls, id):
        try:
            supabase = conectar_supabase()
            supabase.table(("alertas")).select("*", count="exact").eq("id", id).execute()
            res_lote = supabase.table("camaras") \
                .select("*", count="exact") \
                .eq("id", id) \
                .limit(1) \
                .execute()
            res_usuario = supabase.table("produto") \
                .select("*", count="exact") \
                .eq("id", id) \
                .limit(1) \
                .execute()

            total = (res_mov.count or 0) + (res_fornecedores.count or 0) # O count exato fica em res.count
        
            return total > 0
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
    
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca alerta e verifica se ele existe
        alerta = cls.find_by_id(id)
        if not alerta:
            raise ValueError("Alerta não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o alerta porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_alerta(cls, id_alerta):
        supabase = conectar_supabase()
        # Busca o alerta e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("alertas").select("*").eq("id", id_alerta).execute()
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], id_camara=d['id_camara'], id_produto=d['id_produto'], tipo_alerta=d['tipo_alerta'], mensagem=d['mensagem'], nivel=d['nivel'], data_criacao=d['data_criacao'])
        return None
    
    @classmethod
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o alerta
        dados = {"id_camara": self.id_camara, "id_produto": self.id_produto, "tipo_alerta": self.tipo_alerta, "mensagem": self.mensagem, "nivel": self.nivel, "data_criacao": self.data_criacao}
        if self.id:
            return self.db.table("alertas").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("alertas").insert(dados).execute()

 
 
 