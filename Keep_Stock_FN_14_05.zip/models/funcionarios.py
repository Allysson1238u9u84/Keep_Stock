from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Funcionario(CrudBase):
    table = "funcionario"
    fields = [
        "id_usuario",
        "cargo",
        "setor",
        "salario"
    ]

    def __init__(self, id_usuario, cargo, setor, salario):
        self.id_usuario = id_usuario
        self.cargo = cargo
        self.setor = setor
        self.salario = salario
 
    def validate(self):
        erros = [
            Validator.required(self.cargo, "cargo"),
            Validator.required(self.setor, "setor"),
            Validator.non_negative(self.salario, "salario")
        ]
        return [erro for erro in erros if erro]
        
    def __init__ (self, id=None, nome=None, cargo=None, setor=None, salario=None, usuario_id=None):
        self.id = id
        self.nome = nome
        self.cargo = cargo
        self.setor= setor
        self.salario = salario
        self.usuario_id = usuario_id
        self.db = Database.get_client() # Pega o cliente do Supabase

    @classmethod
    def buscar_por_funcionario(cls, id_funcionario):
        supabase = conectar_supabase()
        # Busca um funcionário no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("funcionarios").select("*").eq("funcionario_id", id_funcionario).execute()
        
        if res.data:
            d = res.data[0]
            return cls(id=d['id'], nome=d['nome'], cargo=d['cargo'],setor=d['setor'],salario=d['salario'], usuario_id=d['usuario_id'])
        return None

    def salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o funcionário 
        dados = {"nome": self.nome, "cargo": self.cargo, "setor": self.setor, "salario": self.salario, "usuario_id": self.usuario_id}
        if self.id:
            return self.db.table("funcionarios").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("funcionarios").insert(dados).execute()
    
    def deletar(self):
        supabase = conectar_supabase()
        #Deletar o funcionário 
        if self.id:
            return self.db.table("funcionarios").delete().eq("id", self.id).execute()
        return None


