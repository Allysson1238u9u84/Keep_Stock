from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator


class Lotes(CrudBase):
    table = "lotes"
    fields = [
        "id_produto",
        "id_fornecedor",
        "data_fabricacao"
        "data_validade",
        "quantidade_lote",
        "quantidade_max",
        "quantidade_min"
    
    ]

    def __init__(self, id_produto,id_fornecedor,data_fabricacao,  data_validade, quantidade_lote,quantidade_max, quantidade_min):
        self.id_produto = id_produto
        self.id_fornecedor = id_fornecedor
        self.data_fabricacao = data_fabricacao
        self.data_validade = data_validade
        self.quantidade_lote = quantidade_lote
        self.quantidade_max = quantidade_max
        self.quantidade_min = quantidade_min
        self.db = Database.get_client() # Pega o cliente do Supabase

    def validate(self):
        erros = [
            Validator.required(self.data_fabricacao, "data fabricação"),
            Validator.required(self.data_validade, "data validade"),
            Validator.non_negative(self.quantidade_lote, "quantidade lote"),
            Validator.non_negative(self.quantidade_max, "quantidade maxima"),
            Validator.non_negative(self.quantidade_min, "quantidade minina"),
        ]
        return [erro for erro in erros if erro]  #ARRUMAR AS VALIDAÇÕES!

    @classmethod
    def low_stock(cls, id):
        # Classe de WHERE (Junção de dados da tabela e comparações - quantidade <= quantidade_min)
        supabase = conectar_supabase()
        try:
            supabase.table(("lotes")).select("*", count="exact").eq("id", id).execute()
            res_comparacao = supabase.table("lotes").select("*", count="exact").lte("quantidade", "quantidade_min").execute()
            return res_comparacao.count > 0
        
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
        
    @classmethod
    def max_stock(cls, id):
        # Classe de WHERE (Junção de dados da tabela e comparações - quantidade >= quantidade_max)
        supabase = conectar_supabase()
        try:
            supabase.table(("lotes")).select("*", count="exact").eq("id", id).execute()
            res_comparacao = supabase.table("lotes").select("*", count="exact").gte("quantidade", "quantidade_max").execute()
            return res_comparacao.count > 0
        
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False

    @classmethod
    def has_related_records(cls, id):
        supabase = conectar_supabase()
         # Busca as conexões com outras tabelas relacionadas ao a esta (lote)
        try:
            supabase.table(("usuarios")).select("*", count="exact").eq("id", id).execute()
            res_areas_estoque = supabase.table("areas_estoque") \
            .select("*", count="exact") \
            .eq("id_lote", id) \
            .limit(1) \
            .execute()
            res_descartes = supabase.table("descartes") \
            .select("*", count="exact") \
            .eq("id_lote", id) \
            .limit(1) \
            .execute()
            res_devolucao = supabase.table("devolucao") \
            .select("*", count="exact") \   
            .eq("id_lote", id) \
            .limit(1) \
            execute()
            res_entradas_produtos = supabase.table("entradas_produtos") \
            .eq("id_lote", id) \
            .select("*", count="exact") \   
            .limit(1) \
            .execute()
            res_inspecoes_estoque = supabase.table("inspecoes_estoque")
            .select("*", count="exact")
            .eq("id_lote", id)
            .limit(1)
            .execute()
            res_movimentacoes_estoque = supabase.table("movimentacoes_estoque")
            .select("*", count="exact")
            .eq("id_lote", id)
            .limit(1)
            .execute()
            res_pedido_itens = supabase.table("pedido_itens")
            .select("*", count="exact")
            .eq("id_lote", id)
            .limit(1)
            .execute()
            res_saidas_produtos = supabase.table("saidas_produtos")
            .select("*", count="exact")
            .eq("id_lote", id)
            .limit(1)
            .execute()

            return total > 0
        except Exception as e:
            print(f"Erro ao conectar com Supabase: {e}")
            return False
                
                
    @classmethod
    def safe_delete(cls, id):
        supabase = conectar_supabase()
        # Busca o lote e verifica se ele existe
        lote = cls.find_by_id(id)
        if not lote:
            raise ValueError("lote não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o lote porque possui tabelas vinculadas.")
        cls.delete(id)

    @classmethod
    def buscar_por_lote(cls, id_lote):
        supabase = conectar_supabase()
        # Busca um lote no banco e retorna uma instância da classe
        db = Database.get_client()
        res = db.table("lotes").select("*").eq("id", id_lote).execute()
        if res.data:
            d = res.data[0]
            return cls(produto_id=d['produto_id'], id_fornecedor=d['id_fornecedor'], data_fabricacao=d['data_fabricacao'], data_validade=d['data_validade'], quantidade_lote=d['quantidade_lote'], quantidade_max=d['quantidade_max'], quantidade_min=d['quantidade_min'])
        return None
    
    def inserir_atualizar_salvar(self):
        supabase = conectar_supabase()
        # Insere ou atualiza o lote
        dados = {"produto_id": self.produto_id, "id_fornecedor": self.id_fornecedor, "data_fabricacao": self.data_fabricacao, "data_validade": self.data_validade, "quantidade_lote": self.quantidade_lote, "quantidade_max": self.quantidade_max, "quantidade_min": self.quantidade_min}
        if self.id:
            return self.db.table("lotes").update(dados).eq("id", self.id).execute()
        else:
            return self.db.table("lotes").insert(dados).execute()


