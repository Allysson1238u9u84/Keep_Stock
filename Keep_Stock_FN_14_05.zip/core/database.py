import requests
import urllib.parse
from flask import Flask, request, jsonify
from flask_cors import CORS
from supabase import create_client, Client

app = Flask(__name__)
CORS(app) 

# --- CONFIGURAÇÕES ---
SUPABASE_URL = "https://soikrxoppzuykrilkxii.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNvaWtyeG9wcHp1eWtyaWxreGlpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYyOTQwMjUsImV4cCI6MjA5MTg3MDAyNX0.7sUj-wWHg_Ge9xSmwfX13ec-uvunzujHlUfMnU7Wgdo" 

def conectar_supabase() -> Client:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
    return supabase